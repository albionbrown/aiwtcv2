$(document).ready(function() {
   $('.pwd-recover-toggle').click(function() {
       $('.login_logo').fadeOut(1000);
       $('.pwd-recover-form').css("display","block");
   });
});